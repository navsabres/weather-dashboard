# Weather Dashboard - Vercel Deployment Package

This package contains all the necessary files to deploy the Weather Dashboard application to Vercel.

## Project Overview

The Weather Dashboard is a web application developed as part of the INST 377 course at the University of Maryland. It allows users to search for weather information by city name, displaying current weather conditions including temperature, weather description, humidity, and wind speed.

## Features

- Search for weather by city name
- Toggle between Celsius and Fahrenheit
- Switch between light and dark themes
- View search history
- Persistent user preferences
- Responsive design

## Technology Stack

- Frontend: HTML5, CSS3, JavaScript
- Backend: Node.js, Express.js
- Database: Supabase
- Deployment: Vercel

## Files Included

- `server.js` - Express server that handles API requests
- `package.json` - Project dependencies and scripts
- `vercel.json` - Vercel deployment configuration
- `.env.example` - Example environment variables (rename to .env and add your values)
- `.gitignore` - Git ignore file
- `public/` - Frontend files
  - `index.html` - Main application page
  - `about.html` - About page
  - `css/styles.css` - Stylesheet
  - `js/app.js` - Frontend JavaScript

## Deployment Instructions

1. Create a Vercel account if you don't have one already
2. Install the Vercel CLI: `npm i -g vercel`
3. Clone this repository
4. Create a Supabase project and get your URL and API key
5. Create a `.env` file with your Supabase credentials (use `.env.example` as a template)
6. Run `vercel` in the project directory and follow the prompts
7. Set environment variables in the Vercel dashboard:
   - SUPABASE_URL
   - SUPABASE_KEY
8. Deploy with `vercel --prod`

## Database Schema

### weather_searches Table
- id (primary key)
- city (text)
- temperature (text)
- description (text)
- timestamp (timestamp with time zone, default: now())

### user_preferences Table
- id (primary key)
- theme (text, default: 'light')
- units (text, default: 'celsius')
- default_city (text, default: 'College Park')

## API Endpoints

- GET /api/weather-history - Retrieves the 10 most recent weather searches
- POST /api/weather-history - Saves a new weather search to the history
- GET /api/user-preferences/:userId - Retrieves user preferences
- PUT /api/user-preferences/:userId - Updates user preferences
