# Vercel Deployment Guide for Weather Dashboard

This guide will walk you through the process of deploying the Weather Dashboard application to Vercel.

## Prerequisites

Before you begin, make sure you have:

1. A [Vercel account](https://vercel.com/signup)
2. [Node.js](https://nodejs.org/) installed (version 14 or higher)
3. [Vercel CLI](https://vercel.com/docs/cli) installed globally (`npm i -g vercel`)
4. A [Supabase account](https://supabase.com/) and project

## Step 1: Set Up Supabase

1. Log in to your Supabase account and create a new project
2. Navigate to the SQL Editor in your Supabase dashboard
3. Copy and paste the contents of `supabase_tables.sql` into the SQL Editor
4. Run the SQL queries to create the necessary tables and indexes
5. Go to Project Settings > API to get your Supabase URL and anon key

## Step 2: Configure Environment Variables

1. Create a `.env` file in the root directory of your project (use `.env.example` as a template)
2. Add your Supabase URL and key:
   ```
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_anon_key
   ```

## Step 3: Test Locally (Optional)

Before deploying, you may want to test the application locally:

1. Install dependencies: `npm install`
2. Start the development server: `npm run dev`
3. Open your browser and navigate to `http://localhost:3000`

## Step 4: Deploy to Vercel

### Option 1: Using Vercel CLI

1. Open a terminal in your project directory
2. Run `vercel` and follow the prompts
3. When asked if you want to override the settings, select "Yes"
4. Set up your environment variables when prompted
5. Once the initial deployment is complete, run `vercel --prod` to deploy to production

### Option 2: Using Vercel Dashboard

1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Log in to your Vercel dashboard
3. Click "New Project"
4. Import your repository
5. Configure the project:
   - Framework Preset: Other
   - Build Command: Leave empty (uses default from `vercel.json`)
   - Output Directory: Leave empty (uses default from `vercel.json`)
6. Add environment variables:
   - SUPABASE_URL
   - SUPABASE_KEY
7. Click "Deploy"

## Step 5: Verify Deployment

1. Once deployment is complete, Vercel will provide you with a URL
2. Open the URL in your browser to verify that the application is working correctly
3. Test the following functionality:
   - Search for a city's weather
   - Toggle between Celsius and Fahrenheit
   - Switch between light and dark themes
   - View search history

## Troubleshooting

If you encounter issues with your deployment, check the following:

1. **Environment Variables**: Ensure that your Supabase URL and key are correctly set in the Vercel dashboard
2. **Deployment Logs**: Check the deployment logs in the Vercel dashboard for any errors
3. **Supabase Connection**: Verify that your Supabase project is active and accessible
4. **CORS Issues**: If you're experiencing CORS errors, check your Supabase project settings

## Updating Your Deployment

To update your deployment after making changes:

1. Push your changes to your Git repository (if using Git integration)
2. Run `vercel --prod` (if using Vercel CLI)

Vercel will automatically build and deploy your updated application.

## Custom Domains

To use a custom domain with your Vercel deployment:

1. Go to your project in the Vercel dashboard
2. Navigate to "Settings" > "Domains"
3. Add your domain and follow the instructions to configure DNS settings

## Conclusion

Your Weather Dashboard application should now be successfully deployed to Vercel. The application is serverless and scales automatically based on usage.

For more information on Vercel deployments, refer to the [Vercel documentation](https://vercel.com/docs).
